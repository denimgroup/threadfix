var child = [
  { 'dupe': false, 'type': 100, 'name': 'action=PathTraversal.php', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=PathTraversal.php', 'fetched': true, 'code': 403, 'len': 302, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'iso-8859-1', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 1, 0, 0, 0, 0 ], 'sig': 0xff9ad75f }
];
