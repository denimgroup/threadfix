var issue = [
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 348, 'decl_mime': 'text/html', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10801, 'extra': 'application/javascript', 'fetched': true, 'code': 200, 'len': 348, 'decl_mime': 'text/html', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i1' }
];
