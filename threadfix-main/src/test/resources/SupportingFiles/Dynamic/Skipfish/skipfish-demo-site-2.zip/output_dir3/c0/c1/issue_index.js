var issue = [
  { 'severity': 0, 'type': 10203, 'extra': '[none]', 'fetched': true, 'code': 403, 'len': 289, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i0' },
  { 'severity': 0, 'type': 10202, 'extra': '[none]', 'fetched': true, 'code': 403, 'len': 289, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i1' }
];
