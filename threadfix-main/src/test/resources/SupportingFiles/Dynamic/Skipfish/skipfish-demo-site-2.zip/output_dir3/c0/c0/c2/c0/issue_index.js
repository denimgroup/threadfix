var issue = [
  { 'severity': 0, 'type': 10401, 'extra': '', 'fetched': true, 'code': 403, 'len': 302, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i0' }
];
