var sf_version = '1.92b';
var scan_date  = 'Thu Jun 30 09:48:57 2011';
var scan_seed  = '0x0f691ff7';
var scan_ms    = 14388;
