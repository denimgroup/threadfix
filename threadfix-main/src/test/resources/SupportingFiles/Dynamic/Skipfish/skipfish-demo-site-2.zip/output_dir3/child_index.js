var child = [
  { 'dupe': false, 'type': 10, 'name': 'http://192.168.1.20/', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.1.20/', 'fetched': true, 'code': 200, 'len': 44, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 26, 'issue_cnt': [ 77, 0, 10, 1, 0 ], 'sig': 0x4fcc8259 }
];
