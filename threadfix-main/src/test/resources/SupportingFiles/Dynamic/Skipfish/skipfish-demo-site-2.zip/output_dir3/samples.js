var mime_samples = [
  { 'mime': 'application/javascript', 'samples': [
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'dir': '_m0/0', 'linked': 2, 'len': 592 },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'dir': '_m0/1', 'linked': 2, 'len': 479 },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'dir': '_m0/2', 'linked': 2, 'len': 348 } ]
  },
  { 'mime': 'application/xhtml+xml', 'samples': [
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/', 'dir': '_m1/0', 'linked': 2, 'len': 303 } ]
  },
  { 'mime': 'text/html', 'samples': [
    { 'url': 'http://192.168.1.20/', 'dir': '_m2/0', 'linked': 2, 'len': 44 },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'dir': '_m2/1', 'linked': 2, 'len': 629 },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'dir': '_m2/2', 'linked': 2, 'len': 528 },
    { 'url': 'http://192.168.1.20/demo/', 'dir': '_m2/3', 'linked': 2, 'len': 900 },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php', 'dir': '_m2/4', 'linked': 2, 'len': 325 },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'dir': '_m2/5', 'linked': 2, 'len': 475 },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'dir': '_m2/6', 'linked': 2, 'len': 198 },
    { 'url': 'http://192.168.1.20/demo/FormatString.php', 'dir': '_m2/7', 'linked': 2, 'len': 528 },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'dir': '_m2/8', 'linked': 2, 'len': 342 },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'dir': '_m2/9', 'linked': 2, 'len': 227 },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection.php', 'dir': '_m2/10', 'linked': 2, 'len': 546 },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'dir': '_m2/11', 'linked': 2, 'len': 528 },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'dir': '_m2/12', 'linked': 2, 'len': 388 },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection.php', 'dir': '_m2/13', 'linked': 2, 'len': 641 },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'dir': '_m2/14', 'linked': 2, 'len': 366 },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php', 'dir': '_m2/15', 'linked': 2, 'len': 278 },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'dir': '_m2/16', 'linked': 2, 'len': 629 },
    { 'url': 'http://192.168.1.20/demo/XSS.php', 'dir': '_m2/17', 'linked': 2, 'len': 274 } ]
  }
];

var issue_samples = [
  { 'severity': 3, 'type': 40304, 'samples': [
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i0/0' } ]
  },
  { 'severity': 2, 'type': 30602, 'samples': [
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': '', 'dir': '_i1/0' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i1/1' } ]
  },
  { 'severity': 2, 'type': 30601, 'samples': [
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i2/0' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i2/1' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i2/2' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '', 'dir': '_i2/3' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i2/4' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i2/5' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i2/6' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '', 'dir': '_i2/7' } ]
  },
  { 'severity': 0, 'type': 10901, 'samples': [
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i3/0' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i3/1' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i3/2' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '', 'dir': '_i3/3' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i3/4' },
    { 'url': 'http://192.168.1.20/demo/XPathInjection2.php', 'extra': '', 'dir': '_i3/5' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '', 'dir': '_i3/6' } ]
  },
  { 'severity': 0, 'type': 10803, 'samples': [
    { 'url': 'http://192.168.1.20/', 'extra': '', 'dir': '_i4/0' },
    { 'url': 'http://192.168.1.20/demo/', 'extra': '', 'dir': '_i4/1' },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php', 'extra': '', 'dir': '_i4/2' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'extra': '', 'dir': '_i4/3' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i4/4' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i4/5' },
    { 'url': 'http://192.168.1.20/demo/FormatString.php', 'extra': '', 'dir': '_i4/6' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i4/7' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i4/8' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection.php', 'extra': '', 'dir': '_i4/9' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i4/10' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i4/11' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection.php', 'extra': '', 'dir': '_i4/12' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '', 'dir': '_i4/13' },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php', 'extra': '', 'dir': '_i4/14' },
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': '', 'dir': '_i4/15' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i4/16' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i4/17' },
    { 'url': 'http://192.168.1.20/demo/XPathInjection2.php', 'extra': '', 'dir': '_i4/18' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i4/19' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i4/20' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected.php', 'extra': '', 'dir': '_i4/21' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '', 'dir': '_i4/22' },
    { 'url': 'http://192.168.1.20/demo/XSS.php', 'extra': '', 'dir': '_i4/23' } ]
  },
  { 'severity': 0, 'type': 10801, 'samples': [
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': 'application/javascript', 'dir': '_i5/0' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': 'application/javascript', 'dir': '_i5/1' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': 'application/javascript', 'dir': '_i5/2' } ]
  },
  { 'severity': 0, 'type': 10505, 'samples': [
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': 'cookie', 'dir': '_i6/0' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'extra': 'command', 'dir': '_i6/1' } ]
  },
  { 'severity': 0, 'type': 10401, 'samples': [
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=PathTraversal.php', 'extra': '', 'dir': '_i7/0' } ]
  },
  { 'severity': 0, 'type': 10205, 'samples': [
    { 'url': 'http://192.168.1.20/sfi9876', 'extra': '', 'dir': '_i8/0' },
    { 'url': 'http://192.168.1.20/lpt9', 'extra': '', 'dir': '_i8/1' } ]
  },
  { 'severity': 0, 'type': 10204, 'samples': [
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'extra': 'X-Powered-By', 'dir': '_i9/0' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': 'X-Powered-By', 'dir': '_i9/1' },
    { 'url': 'http://192.168.1.20/demo/FormatString.php', 'extra': 'X-Powered-By', 'dir': '_i9/2' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': 'X-Powered-By', 'dir': '_i9/3' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection.php', 'extra': 'X-Powered-By', 'dir': '_i9/4' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': 'X-Powered-By', 'dir': '_i9/5' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection.php', 'extra': 'X-Powered-By', 'dir': '_i9/6' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': 'X-Powered-By', 'dir': '_i9/7' },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php', 'extra': 'X-Powered-By', 'dir': '_i9/8' },
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': 'X-Powered-By', 'dir': '_i9/9' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': 'X-Powered-By', 'dir': '_i9/10' },
    { 'url': 'http://192.168.1.20/demo/XPathInjection2.php', 'extra': 'X-Powered-By', 'dir': '_i9/11' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': 'X-Powered-By', 'dir': '_i9/12' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected.php', 'extra': 'X-Powered-By', 'dir': '_i9/13' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': 'X-Powered-By', 'dir': '_i9/14' },
    { 'url': 'http://192.168.1.20/demo/XSS.php', 'extra': 'X-Powered-By', 'dir': '_i9/15' } ]
  },
  { 'severity': 0, 'type': 10203, 'samples': [
    { 'url': 'http://192.168.1.20/', 'extra': '1.1 127.0.1.1', 'dir': '_i10/0' },
    { 'url': 'http://192.168.1.20/demo/', 'extra': '1.1 127.0.1.1', 'dir': '_i10/1' },
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/', 'extra': '[none]', 'dir': '_i10/2' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/3' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/4' },
    { 'url': 'http://192.168.1.20/demo/FormatString.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/5' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/6' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/7' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/8' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/9' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/10' },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/11' },
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/12' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/13' },
    { 'url': 'http://192.168.1.20/demo/XPathInjection2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/14' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/15' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/16' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/17' },
    { 'url': 'http://192.168.1.20/demo/XSS.php', 'extra': '1.1 127.0.1.1', 'dir': '_i10/18' } ]
  },
  { 'severity': 0, 'type': 10202, 'samples': [
    { 'url': 'http://192.168.1.20/', 'extra': 'Apache/2.2.19 (Win32) PHP/5.3.6', 'dir': '_i11/0' },
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/', 'extra': '[none]', 'dir': '_i11/1' } ]
  },
  { 'severity': 0, 'type': 10201, 'samples': [
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': 'vuln', 'dir': '_i12/0' } ]
  }
];

