$(document).ready(function() {
	$(".focus").focus();
});

if(top != self) top.location.replace(location);