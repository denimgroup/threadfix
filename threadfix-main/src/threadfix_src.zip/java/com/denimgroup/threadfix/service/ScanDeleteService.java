package com.denimgroup.threadfix.service;

import com.denimgroup.threadfix.data.entities.Scan;

public interface ScanDeleteService {

	/**
	 * 
	 * @param scan
	 */
	void deleteScan(Scan scan);
	
}
