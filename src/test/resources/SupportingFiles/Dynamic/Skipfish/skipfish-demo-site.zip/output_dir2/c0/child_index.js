var child = [
  { 'dupe': false, 'type': 11, 'name': 'demo', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.1.20/demo/', 'fetched': true, 'code': 200, 'len': 900, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 31, 'issue_cnt': [ 80, 0, 10, 12, 3 ], 'sig': 0x7e22fe72 },
  { 'dupe': false, 'type': 12, 'name': 'demo.zip', 'dir': 'c1', 'linked': 0, 'url': 'http://192.168.1.20/demo.zip', 'fetched': true, 'code': 200, 'len': 38, 'decl_mime': 'application/zip', 'sniff_mime': 'application/zip', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xfff3ffff }
];
