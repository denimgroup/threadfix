var child = [
  { 'dupe': false, 'type': 100, 'name': 'cookie=1', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.1.20/demo/XSS-cookie.php DATA:cookie=1', 'fetched': true, 'code': 302, 'len': 629, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 2, 0, 1, 2, 0 ], 'sig': 0x31ee350a }
];
