var child = [
  { 'dupe': false, 'type': 12, 'name': 'admin.txt', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.1.20/demo/DirectoryIndexing/admin.txt', 'fetched': true, 'code': 200, 'len': 226, 'decl_mime': 'text/plain', 'sniff_mime': 'text/html', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 2, 0, 0, 0, 0 ], 'sig': 0xc5c0f230 }
];
