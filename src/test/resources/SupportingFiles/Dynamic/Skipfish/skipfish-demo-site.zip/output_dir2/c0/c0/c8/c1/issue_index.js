var issue = [
  { 'severity': 4, 'type': 50103, 'extra': 'response to \x27\x22 different than to \x5c\x27\x5c\x22', 'fetched': true, 'code': 200, 'len': 388, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 388, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' }
];
