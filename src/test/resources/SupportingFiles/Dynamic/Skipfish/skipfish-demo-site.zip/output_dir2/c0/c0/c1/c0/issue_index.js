var issue = [
  { 'severity': 3, 'type': 40501, 'extra': 'responses for ./val and .../val look different', 'fetched': true, 'code': 200, 'len': 1039, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 3, 'type': 40501, 'extra': 'responses for .\x5cval and ...\x5cval look different', 'fetched': true, 'code': 200, 'len': 1039, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 3, 'type': 40304, 'extra': '', 'fetched': true, 'code': 200, 'len': 861, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 3, 'type': 40301, 'extra': 'text/plain', 'fetched': true, 'code': 200, 'len': 861, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i3' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 794, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i4' },
  { 'severity': 0, 'type': 10801, 'extra': 'text/plain', 'fetched': true, 'code': 200, 'len': 794, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i5' }
];
