var issue = [
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 267, 'decl_mime': 'text/plain', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10801, 'extra': 'text/html', 'fetched': true, 'code': 200, 'len': 267, 'decl_mime': 'text/plain', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' }
];
