var issue = [
  { 'severity': 3, 'type': 40401, 'extra': 'Directory listing', 'fetched': true, 'code': 200, 'len': 297, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10204, 'extra': 'X-Pad', 'fetched': true, 'code': 200, 'len': 297, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i1' },
  { 'severity': 0, 'type': 10203, 'extra': '1.1 127.0.1.1', 'fetched': true, 'code': 200, 'len': 297, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i2' }
];
