var issue = [
  { 'severity': 0, 'type': 10901, 'extra': '', 'fetched': true, 'code': 200, 'len': 369, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 369, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10204, 'extra': 'X-Powered-By', 'fetched': true, 'code': 200, 'len': 369, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10203, 'extra': '1.1 127.0.1.1', 'fetched': true, 'code': 200, 'len': 369, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i3' }
];
