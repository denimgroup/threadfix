var issue = [
  { 'severity': 4, 'type': 50103, 'extra': 'response to \x27\x22 different than to \x5c\x27\x5c\x22', 'fetched': true, 'code': 200, 'len': 519, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 3, 'type': 40402, 'extra': 'SQL server error', 'fetched': true, 'code': 200, 'len': 519, 'decl_mime': 'text/html', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 348, 'decl_mime': 'text/html', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10801, 'extra': 'application/javascript', 'fetched': true, 'code': 200, 'len': 348, 'decl_mime': 'text/html', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i3' }
];
