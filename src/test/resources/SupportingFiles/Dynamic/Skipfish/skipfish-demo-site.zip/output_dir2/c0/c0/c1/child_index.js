var child = [
  { 'dupe': false, 'type': 100, 'name': 'action=PathTraversal.php', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=PathTraversal.php', 'fetched': true, 'code': 200, 'len': 331, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 1, 'issue_cnt': [ 4, 0, 0, 4, 0 ], 'sig': 0xc537bd79 }
];
