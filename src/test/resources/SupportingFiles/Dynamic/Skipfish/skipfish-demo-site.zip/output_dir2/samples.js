var mime_samples = [
  { 'mime': 'application/javascript', 'samples': [
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'dir': '_m0/0', 'linked': 2, 'len': 592 },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'dir': '_m0/1', 'linked': 2, 'len': 479 },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'dir': '_m0/2', 'linked': 2, 'len': 348 },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'dir': '_m0/3', 'linked': 2, 'len': 519 } ]
  },
  { 'mime': 'application/xhtml+xml', 'samples': [
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/', 'dir': '_m1/0', 'linked': 2, 'len': 297 } ]
  },
  { 'mime': 'application/zip', 'samples': [
    { 'url': 'http://192.168.1.20/demo.zip', 'dir': '_m2/0', 'linked': 0, 'len': 38 } ]
  },
  { 'mime': 'text/html', 'samples': [
    { 'url': 'http://192.168.1.20/', 'dir': '_m3/0', 'linked': 2, 'len': 44 },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'dir': '_m3/1', 'linked': 2, 'len': 629 },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'dir': '_m3/2', 'linked': 2, 'len': 528 },
    { 'url': 'http://192.168.1.20/demo/', 'dir': '_m3/3', 'linked': 2, 'len': 900 },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php', 'dir': '_m3/4', 'linked': 2, 'len': 325 },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php.bak', 'dir': '_m3/5', 'linked': 1, 'len': 267 },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'dir': '_m3/6', 'linked': 2, 'len': 475 },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'dir': '_m3/7', 'linked': 2, 'len': 198 },
    { 'url': 'http://192.168.1.20/demo/FormatString.php', 'dir': '_m3/8', 'linked': 2, 'len': 528 },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'dir': '_m3/9', 'linked': 2, 'len': 342 },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'dir': '_m3/10', 'linked': 2, 'len': 227 },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection.php', 'dir': '_m3/11', 'linked': 2, 'len': 546 },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'dir': '_m3/12', 'linked': 2, 'len': 528 },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'dir': '_m3/13', 'linked': 2, 'len': 388 },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection.php', 'dir': '_m3/14', 'linked': 2, 'len': 641 },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'dir': '_m3/15', 'linked': 2, 'len': 366 },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php', 'dir': '_m3/16', 'linked': 2, 'len': 278 },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'dir': '_m3/17', 'linked': 2, 'len': 629 },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'dir': '_m3/18', 'linked': 2, 'len': 261 },
    { 'url': 'http://192.168.1.20/demo/XSS.php', 'dir': '_m3/19', 'linked': 2, 'len': 274 } ]
  },
  { 'mime': 'text/plain', 'samples': [
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=PathTraversal.php--\x3e\x22\x3e\x27\x3e\x27\x22\x3csfi000058v497011\x3e', 'dir': '_m4/0', 'linked': 2, 'len': 861 },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=nul', 'dir': '_m4/1', 'linked': 0, 'len': 255 } ]
  }
];

var issue_samples = [
  { 'severity': 4, 'type': 50103, 'samples': [
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': 'response to \x27\x22 different than to \x5c\x27\x5c\x22', 'dir': '_i0/0' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': 'response to \x27\x22 different than to \x5c\x27\x5c\x22', 'dir': '_i0/1' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': 'response to \x27\x22 different than to \x5c\x27\x5c\x22', 'dir': '_i0/2' } ]
  },
  { 'severity': 3, 'type': 40501, 'samples': [
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=./PathTraversal.php', 'extra': 'responses for ./val and .../val look different', 'dir': '_i1/0' },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=.\x5cPathTraversal.php', 'extra': 'responses for .\x5cval and ...\x5cval look different', 'dir': '_i1/1' } ]
  },
  { 'severity': 3, 'type': 40402, 'samples': [
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': 'SQL server error', 'dir': '_i2/0' } ]
  },
  { 'severity': 3, 'type': 40401, 'samples': [
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/', 'extra': 'Directory listing', 'dir': '_i3/0' } ]
  },
  { 'severity': 3, 'type': 40304, 'samples': [
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=PathTraversal.php--\x3e\x22\x3e\x27\x3e\x27\x22\x3csfi000058v497011\x3e', 'extra': '', 'dir': '_i4/0' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i4/1' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i4/2' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i4/3' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '', 'dir': '_i4/4' } ]
  },
  { 'severity': 3, 'type': 40301, 'samples': [
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=PathTraversal.php--\x3e\x22\x3e\x27\x3e\x27\x22\x3csfi000058v497011\x3e', 'extra': 'text/plain', 'dir': '_i5/0' } ]
  },
  { 'severity': 3, 'type': 40101, 'samples': [
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': 'injected \x27\x3csfi...\x3e\x27 tag seen in HTML', 'dir': '_i6/0' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': 'injected \x27\x3csfi...\x3e\x27 tag seen in HTML', 'dir': '_i6/1' } ]
  },
  { 'severity': 2, 'type': 30602, 'samples': [
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': '', 'dir': '_i7/0' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i7/1' } ]
  },
  { 'severity': 2, 'type': 30601, 'samples': [
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i8/0' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i8/1' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i8/2' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '', 'dir': '_i8/3' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i8/4' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i8/5' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i8/6' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '', 'dir': '_i8/7' } ]
  },
  { 'severity': 0, 'type': 10901, 'samples': [
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i9/0' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i9/1' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i9/2' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '', 'dir': '_i9/3' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i9/4' },
    { 'url': 'http://192.168.1.20/demo/XPathInjection2.php', 'extra': '', 'dir': '_i9/5' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '', 'dir': '_i9/6' } ]
  },
  { 'severity': 0, 'type': 10803, 'samples': [
    { 'url': 'http://192.168.1.20/', 'extra': '', 'dir': '_i10/0' },
    { 'url': 'http://192.168.1.20/demo/', 'extra': '', 'dir': '_i10/1' },
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/admin.txt', 'extra': '', 'dir': '_i10/2' },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php', 'extra': '', 'dir': '_i10/3' },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=.../PathTraversal.php', 'extra': '', 'dir': '_i10/4' },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=nul', 'extra': '', 'dir': '_i10/5' },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php.bak', 'extra': '', 'dir': '_i10/6' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'extra': '', 'dir': '_i10/7' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i10/8' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '', 'dir': '_i10/9' },
    { 'url': 'http://192.168.1.20/demo/FormatString.php', 'extra': '', 'dir': '_i10/10' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i10/11' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '', 'dir': '_i10/12' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection.php', 'extra': '', 'dir': '_i10/13' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i10/14' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i10/15' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '', 'dir': '_i10/16' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection.php', 'extra': '', 'dir': '_i10/17' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '', 'dir': '_i10/18' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '', 'dir': '_i10/19' },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php', 'extra': '', 'dir': '_i10/20' },
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': '', 'dir': '_i10/21' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i10/22' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '', 'dir': '_i10/23' },
    { 'url': 'http://192.168.1.20/demo/XPathInjection2.php', 'extra': '', 'dir': '_i10/24' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i10/25' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '', 'dir': '_i10/26' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected.php', 'extra': '', 'dir': '_i10/27' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '', 'dir': '_i10/28' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '', 'dir': '_i10/29' },
    { 'url': 'http://192.168.1.20/demo/XSS.php', 'extra': '', 'dir': '_i10/30' } ]
  },
  { 'severity': 0, 'type': 10801, 'samples': [
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/admin.txt', 'extra': 'text/html', 'dir': '_i11/0' },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=.../PathTraversal.php', 'extra': 'text/plain', 'dir': '_i11/1' },
    { 'url': 'http://192.168.1.20/demo/PathTraversal.php?action=nul', 'extra': 'text/plain', 'dir': '_i11/2' },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php.bak', 'extra': 'text/html', 'dir': '_i11/3' },
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': 'application/javascript', 'dir': '_i11/4' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': 'application/javascript', 'dir': '_i11/5' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': 'application/javascript', 'dir': '_i11/6' } ]
  },
  { 'severity': 0, 'type': 10505, 'samples': [
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': 'cookie', 'dir': '_i12/0' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'extra': 'command', 'dir': '_i12/1' } ]
  },
  { 'severity': 0, 'type': 10205, 'samples': [
    { 'url': 'http://192.168.1.20/sfi9876', 'extra': '', 'dir': '_i13/0' },
    { 'url': 'http://192.168.1.20/lpt9', 'extra': '', 'dir': '_i13/1' } ]
  },
  { 'severity': 0, 'type': 10204, 'samples': [
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/', 'extra': 'X-Pad', 'dir': '_i14/0' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'extra': 'X-Powered-By', 'dir': '_i14/1' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': 'X-Powered-By', 'dir': '_i14/2' },
    { 'url': 'http://192.168.1.20/demo/FormatString.php', 'extra': 'X-Powered-By', 'dir': '_i14/3' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': 'X-Powered-By', 'dir': '_i14/4' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection.php', 'extra': 'X-Powered-By', 'dir': '_i14/5' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': 'X-Powered-By', 'dir': '_i14/6' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection.php', 'extra': 'X-Powered-By', 'dir': '_i14/7' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': 'X-Powered-By', 'dir': '_i14/8' },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php', 'extra': 'X-Powered-By', 'dir': '_i14/9' },
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': 'X-Powered-By', 'dir': '_i14/10' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': 'X-Powered-By', 'dir': '_i14/11' },
    { 'url': 'http://192.168.1.20/demo/XPathInjection2.php', 'extra': 'X-Powered-By', 'dir': '_i14/12' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': 'X-Powered-By', 'dir': '_i14/13' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected.php', 'extra': 'X-Powered-By', 'dir': '_i14/14' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': 'X-Powered-By', 'dir': '_i14/15' },
    { 'url': 'http://192.168.1.20/demo/XSS.php', 'extra': 'X-Powered-By', 'dir': '_i14/16' } ]
  },
  { 'severity': 0, 'type': 10203, 'samples': [
    { 'url': 'http://192.168.1.20/', 'extra': '1.1 127.0.1.1', 'dir': '_i15/0' },
    { 'url': 'http://192.168.1.20/demo/', 'extra': '1.1 127.0.1.1', 'dir': '_i15/1' },
    { 'url': 'http://192.168.1.20/demo/DirectoryIndexing/', 'extra': '1.1 127.0.1.1', 'dir': '_i15/2' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/3' },
    { 'url': 'http://192.168.1.20/demo/EvalInjection2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/4' },
    { 'url': 'http://192.168.1.20/demo/FormatString.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/5' },
    { 'url': 'http://192.168.1.20/demo/FormatString2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/6' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/7' },
    { 'url': 'http://192.168.1.20/demo/LDAPInjection2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/8' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/9' },
    { 'url': 'http://192.168.1.20/demo/OSCommandInjection2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/10' },
    { 'url': 'http://192.168.1.20/demo/PredictableResource.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/11' },
    { 'url': 'http://192.168.1.20/demo/SQLI.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/12' },
    { 'url': 'http://192.168.1.20/demo/SQLI2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/13' },
    { 'url': 'http://192.168.1.20/demo/XPathInjection2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/14' },
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/15' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/16' },
    { 'url': 'http://192.168.1.20/demo/XSS-reflected2.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/17' },
    { 'url': 'http://192.168.1.20/demo/XSS.php', 'extra': '1.1 127.0.1.1', 'dir': '_i15/18' } ]
  },
  { 'severity': 0, 'type': 10202, 'samples': [
    { 'url': 'http://192.168.1.20/', 'extra': 'Apache/2.2.19 (Win32) PHP/5.3.6', 'dir': '_i16/0' } ]
  },
  { 'severity': 0, 'type': 10201, 'samples': [
    { 'url': 'http://192.168.1.20/demo/XSS-cookie.php', 'extra': 'vuln', 'dir': '_i17/0' } ]
  }
];

