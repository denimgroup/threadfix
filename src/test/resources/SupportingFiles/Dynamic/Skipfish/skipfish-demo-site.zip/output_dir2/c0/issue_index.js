var issue = [
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 44, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10505, 'extra': 'cookie', 'fetched': true, 'code': 200, 'len': 629, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10505, 'extra': 'command', 'fetched': true, 'code': 200, 'len': 528, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10205, 'extra': '', 'fetched': true, 'code': 404, 'len': 205, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i3' },
  { 'severity': 0, 'type': 10205, 'extra': '', 'fetched': true, 'code': 403, 'len': 206, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i4' },
  { 'severity': 0, 'type': 10203, 'extra': '1.1 127.0.1.1', 'fetched': true, 'code': 200, 'len': 44, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i5' },
  { 'severity': 0, 'type': 10202, 'extra': 'Apache/2.2.19 (Win32) PHP/5.3.6', 'fetched': true, 'code': 200, 'len': 44, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i6' }
];
