var issue = [
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 255, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10801, 'extra': 'text/plain', 'fetched': true, 'code': 200, 'len': 255, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i1' }
];
